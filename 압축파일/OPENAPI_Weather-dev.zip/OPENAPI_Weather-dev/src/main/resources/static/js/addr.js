
// addr1,addr2,addr3 Selector
const addr1El = document.forms[0].addr1;
const addr2El = document.forms[0].addr2;
const addr3El = document.forms[0].addr3;

   //검색버튼 눌렀을 때
const reqInfo = ()=>{
       addr1 = addr1El.options[addr1El.selectedIndex].value;
       addr2 = addr2El.options[addr2El.selectedIndex].value;
       addr3 = addr3El.options[addr3El.selectedIndex].value;
       addr = addr1+" " + addr2+" " + addr3;

       map(addr);

       reqJSON('OpenAPI1',addr1,addr2,addr3);
}

//addr1 select시 addr2를 가져오게 하는 이벤트 처리 함수
addr1El.addEventListener('change', function(e) {
            //기존 자식 노드 삭제
            while(addr2El.hasChildNodes()){
                addr2El.removeChild(addr2El.firstChild);
            }

            addr1 = addr1El.options[addr1El.selectedIndex].value;
                //서버로 요청해야한다
                fetch(`http://localhost:8080/reqaddr2/${addr1}`)
                    .then( (response)=>response.json() )
                    .then(array=>{
                        console.log(array);
                        for(idx in array){

                            let optionEl = document.createElement("option");
                            optionEl.value=array[idx];
                            optionEl.innerHTML=array[idx];
                            if(idx==0)
                                optionEl.selected=true;
                            addr2El.appendChild(optionEl);
                        }
                    })
                    .catch( (error)=>console.log(error));
        });

//addr2 select시 addr3를 가져오게 하는 이벤트 처리 함수
addr2El.addEventListener('change', function(e) {
            //기존 자식 노드 삭제
            while(addr3El.hasChildNodes()){
               addr3El.removeChild(addr3El.firstChild);
            }

            addr1 = addr1El.options[addr1El.selectedIndex].value;
            addr2 = addr2El.options[addr2El.selectedIndex].value;
                //서버로 요청해야한다
                fetch(`http://localhost:8080/reqaddr3/${addr1}/${addr2}`)
                    .then( (response)=>response.json() )
                    .then(array=>{
                        console.log(array);
                        for(idx in array){

                            let optionEl = document.createElement("option");
                            optionEl.value=array[idx];
                            optionEl.innerHTML=array[idx];
                            if(idx==0)
                                optionEl.selected=true;
                            addr3El.appendChild(optionEl);
                        }
                    })
                    .catch( (error)=>console.log(error));
});
