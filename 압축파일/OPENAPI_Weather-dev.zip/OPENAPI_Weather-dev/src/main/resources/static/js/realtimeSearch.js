//JSON Data 요청
const reqJSON = (url,addr1,addr2,addr3)=>{

        const t1h = document.querySelector(".t1h");
        const rn1 = document.querySelector(".rn1");
        const uuu = document.querySelector(".uuu");
        const vvv = document.querySelector(".vvv");
        const reh = document.querySelector(".reh");
        const pty = document.querySelector(".pty");
        const vec = document.querySelector(".vec");
        const wsd = document.querySelector(".wsd");

        t1h.innerHTML="";
        rn1.innerHTML="";
        uuu.innerHTML="";
        vvv.innerHTML="";
        reh.innerHTML="";
        pty.innerHTML="";
        vec.innerHTML="";
        wsd.innerHTML="";

     fetch(`http://localhost:8080/${url}/${addr1}/${addr2}/${addr3}`)
        .then( (response)=>response.json() )
        .then( (array)=>{
            console.log(array);
            console.log(array.item[3]["obsrValue"]);
            //강수형태
            pty.innerHTML  = array.item[0]["obsrValue"]+" "; //(초단기) 없음(0), 비(1), 비/눈(2), 눈(3), 빗방울(5), 빗방울눈날림(6), 눈날림(7)

            reh.innerHTML  = array.item[1]["obsrValue"]+" %";
            rn1.innerHTML  = array.item[2]["obsrValue"]+" mm";
            t1h.innerHTML  = array.item[3]["obsrValue"]+" &#8451;";

            //동서바람 성분 + 동 - 북
            uuu.innerHTML  = array.item[4]["obsrValue"]+" m/s";
            vec.innerHTML  = array.item[5]["obsrValue"]+" deg";
//          //남북바람 성분 (+ 북) (- 남)
            vvv.innerHTML  = array.item[6]["obsrValue"]+" m/s";
            wsd.innerHTML  = array.item[7]["obsrValue"]+" m/s";





        })
        .catch( (error)=>console.log(error));
 }