package com.example.demo.repository;

import com.example.demo.entity.Weather;
import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.FluentQuery;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.function.Function;

@Repository
public interface WeatherRepository extends JpaRepository<Weather, Long> {

    List<Weather> findByAddr1LikeAndAddr2(String addr1 , String addr2);

    List<Weather> findByAddr1Like(String addr1);

    List<Weather> findByAddr1AndAddr2(String addr1, String addr2);


}


