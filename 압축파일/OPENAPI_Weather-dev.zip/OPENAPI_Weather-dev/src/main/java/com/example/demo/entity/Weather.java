package com.example.demo.entity;


import lombok.Data;

import javax.persistence.*;


@Entity
@Data
public class Weather {

    @Id
    @Column
    private Long code;

    @Column
    private String addr1;

    @Column
    private String addr2;
    @Column
    private String addr3;
    @Column
    private Integer nx;
    @Column
    private Integer ny;


}