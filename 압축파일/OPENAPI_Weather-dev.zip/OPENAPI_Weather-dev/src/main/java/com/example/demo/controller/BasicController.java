package com.example.demo.controller;


import com.example.demo.entity.Weather;
import com.example.demo.repository.WeatherRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@Slf4j
@RequestMapping("/APITest")
@RequiredArgsConstructor
public class BasicController {

   private final WeatherRepository weatherRepository;



    @GetMapping("/Weather_JSON")
    public void func1(Model model){

        log.info("URL : /APITest/Weather_JSON");


    }


    @GetMapping("/Weather_XML")
    public void func3()
    {

        log.info("URL : /APITest/Weather_XML");
    }

}
