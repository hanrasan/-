package com.example.demo;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class APITest {

    public static void main(String[] args) throws Exception {
        System.out.println("HELLO WORLD");

        
        //URL 설정
        String addr = "https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst?serviceKey=xYZ80mMcU8S57mCCY%2Fq8sRsk7o7G8NtnfnK7mVEuVxdtozrl0skuhvNf34epviHrru%2FjiRQ41FokE9H4lK0Hhg%3D%3D&pageNo=1&numOfRows=100&dataType=json&base_date=20230317&base_time=1200&nx=89&ny=90";
        URL url = new URL(addr);

        //서버->JAVA 방향 스트림 객체
        BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(),"utf-8"));

        StringBuffer buff = new StringBuffer(); //데이터 저장용

        //데이터 가져오기
        String cnt = null;
        while(true)
        {
            cnt = in.readLine();
            if(cnt==null)
                break;
            //System.out.println(cnt);
            buff.append(cnt);
        }
        System.out.println(buff.toString());

        //String ->JSON 변환
        JSONParser parser = new JSONParser();
        JSONObject dataObject= (JSONObject)parser.parse(buff.toString());



    }
}
