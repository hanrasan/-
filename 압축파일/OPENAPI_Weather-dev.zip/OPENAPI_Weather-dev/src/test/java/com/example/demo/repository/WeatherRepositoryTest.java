package com.example.demo.repository;

import com.example.demo.entity.Weather;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class WeatherRepositoryTest {

    @Autowired
    WeatherRepository wr;
    @Test
    public void func(){
        //List<Weather> list = wr.findByAddr1LikeAndAddr2("%대구%","중구");
        //System.out.println(list);

       // List<Weather> list = wr.findByAddr1Field("대구광역시");
       // System.out.println(wr);



    }

}