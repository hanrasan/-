
## 기상청 조회 OPEN API 
- 시간이 없어서 여기까지만 했습니다. 확인해보세요.
- 정시를 기준으로 실황 조회를 합니다. (ex. 17:44 -> 17:00으로 조회)
- 정시와 가까운 시간에 조회를 하면 에러가 발생하기도합니다. 완성도 있게 구현하는게 아니라
- OPEN API를 어떻게 활용하는지에 초점을 두었습니다.
- 부족한게 많지만 여기까지만 할게요.. 할일이 많아서 ^^;;
- 시간날때 조금씩 수정해놓을께요 ㅎ
------------------------
### Database
- Mysql 8.x
- ID : root
- PW : 1234
- 생성할 DB : testdb
- 생성할 Tbl : weather
- Project 실행시 자동 Insert 됩니다.

------------------------
## ENDPOINT                
GET /OpenAPI1/{addr1}/{addr2}/{addr3}   기상청 초단기 실황 조회 자료 리턴<br/>
GET /reqaddr2/{addr1}                   DB로부터 addr2 리스트 받아오기 (중복제거)<br/>
GET /reqaddr3/{addr1}/{addr2}           Db로부터 addr3 리스트 받아오기 (중복제거)<br/>
GET /APITest/Weather_JSON               기상청 조회 화면 출력용<br/>
------------------------
## IntelliJ 실행

![20230319213221](https://user-images.githubusercontent.com/84259104/226175403-5cafbd58-d222-42ca-b467-58fd8eca7d0f.png)

------------------------
## IntelliJ 설정
![20230316210441](https://user-images.githubusercontent.com/84259104/226175253-0aba2ed5-2d1b-4074-aeab-00f47c31bd69.png)

------------------------
## 결과
![20230319201915](https://user-images.githubusercontent.com/84259104/226174870-ce734394-5776-440e-a636-936c173c30be.png)

![20230319203734](https://user-images.githubusercontent.com/84259104/226174875-de409c89-82d7-4263-9c64-0dcd56685312.png)

![20230319203740](https://user-images.githubusercontent.com/84259104/226174877-caf90077-0f59-4ac1-97a8-e83aaef1028b.png)

![20230319203745](https://user-images.githubusercontent.com/84259104/226174879-2d1458f5-e5df-4343-96c4-e37134dddff7.png)

------------------------
## 참고

![20230319212909](https://user-images.githubusercontent.com/84259104/226175289-63cd9514-1479-482b-98ca-35c90b3bb010.png)

![20230319212927](https://user-images.githubusercontent.com/84259104/226175292-9c92020d-2244-4bd5-aa65-2e1626889853.png)


